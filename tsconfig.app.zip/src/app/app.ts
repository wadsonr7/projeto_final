import { Component, signal } from '@angular/core';


@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class AppComponent {
 protected readonly title = signal('Meu Aplicativo Angular');
}
