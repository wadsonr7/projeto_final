// // meu-componente.component.ts
// import { Component, OnInit, inject } from '@angular/core';
// import { ApiService } from '../services/api';
// import { Router } from '@angular/router';
// import { FormsModule } from '@angular/forms'; // Necessário se for um componente Standalone
// import { CommonModule } from '@angular/common'; // Necessário para usar o *ngIf

// @Component({
//   selector: 'app-login',
//   standalone: true, // Remova essa linha se o seu projeto usar o padrão antigo de AppModules
//   imports: [FormsModule, CommonModule], // Remova essa linha se o seu projeto usar AppModules
//   templateUrl: './login.html',
//   styleUrls: ['./login.css'], // Certifique-off se o seu arquivo de estilo chama login.css
// })
// export class LoginComponent {
//   // Propriedades vinculadas ao formulário usando [(ngModel)]
//   usuario = '';
//   senha = '';
//   erroMensagem = '';

//   constructor(private router: Router) {}

//   // Função que o formulário chama ao ser enviado pelo (ngSubmit)
//   onSubmit(): void {
//     // Validação mockada com os dados solicitados pelo enunciado: admin / 123456
//     if (this.usuario === 'admin' && this.senha === '123456') {
//       this.erroMensagem = '';
//       localStorage.setItem('isLoggedIn', 'true');

//       // Redireciona para a próxima rota (mude para o nome correto da sua rota do dashboard se necessário)
//       this.router.navigate(['/home']);
//     } else {
//       this.erroMensagem = 'Usuário ou senha inválidos.';
//     }
//   }
// }

// login.component.ts
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  // IMPORTANTE: precisamos importar o ReactiveFormsModule para os formulários funcionarem
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class LoginComponent {
  // Injeções modernas
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  // Variáveis do componente
  loginForm: FormGroup;
  mensagemErro: string = '';
  carregando: boolean = false;

  constructor() {
    // Inicializa o formulário com validações básicas
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      contrasenia: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  // A FUNÇÃO DO COMPONENTE
  onLogin(): void {
    // 1. Se o formulário for inválido, não faz nada
    if (this.loginForm.invalid) {
      return;
    }

    this.carregando = true;
    this.mensagemErro = '';

    // 2. Extrai os dados validados do formulário
    const dadosLogin = this.loginForm.value;

    // 3. Chama o serviço passando os dados
    this.authService.login(dadosLogin).subscribe({
      next: (resposta) => {
        this.carregando = false;
        console.log('Login efetuado com sucesso!', resposta);

        // 4. Redireciona o usuário para a área restrita
        this.router.navigate(['/home']);
      },
      error: (erro) => {
        this.carregando = false;
        // Trata mensagens de erro que vêm da sua API (ex: "Senha incorreta")
        this.mensagemErro = erro.error?.message || 'Falha ao efetuar login. Tente novamente.';
        console.error('Erro no login:', erro);
      },
    });
  }
}
