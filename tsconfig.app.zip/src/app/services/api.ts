// api.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root', // Torna o serviço disponível no app inteiro
})
export class ApiService {
  // Injeta o HttpClient de forma moderna
  private http = inject(HttpClient);
  private apiUrl = 'https://localhost/3001/'; // API de teste

  // Método para buscar os dados (retorna um Observable)
  getPosts(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }
}
