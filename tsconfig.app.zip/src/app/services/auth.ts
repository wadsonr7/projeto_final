// auth.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

export interface LoginRequest {
  email: string;
  contrasenia: string; // ou password
}

export interface LoginResponse {
  token: string;
  usuario: {
    id: number;
    nome: string;
    email: string;
  };
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private http = inject(HttpClient);
  private apiUrl = 'https://localhost/3001'; // Substitua pela sua URL

  login(credenciais: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credenciais).pipe(
      // O 'tap' serve para executarmos um efeito colateral se a requisição der certo
      tap((resposta) => {
        if (resposta && resposta.token) {
          // Salva o token no navegador para o usuário continuar logado
          localStorage.setItem('auth_token', resposta.token);
        }
      }),
    );
  }

  // Método auxiliar útil para outras partes do app saberem se está logado
  isAutenticado(): boolean {
    return !!localStorage.getItem('auth_token');
  }

  logout(): void {
    localStorage.removeItem('auth_token');
  }
}
